const express = require('express');
const multer = require('multer'); //Importa o Multer para manipulação de uploads
const path = require('path');
const fs = require('fs'); //Importa módulos para trabalhar com o sistema de arquivos


const app = express();
const port = 3000;

/*
__dirname: Variável que contém o caminho para o diretório onde o script atual está sendo executado.
*/

// Define o caminho para a pasta de uploads
const uploadDir = path.join(__dirname, 'uploads');

//Se O diretório de uploads não existir, ele o cria.
//Por motivo de segurança, a pasta é criada dentro do
// seu projeto. 
if (!fs.existsSync(uploadDir)) {
    fs.mkdirSync(uploadDir);
}

//multer.diskStorage(): É a configuração que diz ao Multer para salvar os arquivos no disco do servidor.
const storage = multer.diskStorage({

    //destination: Esta função determina em qual pasta o arquivo será salvo.
    
    //cb(null, uploadDir) é um callback que diz: "Não houve erro (null) e a pasta de destino é a que definimos na variável uploadDir".

    // Define a pasta de destino para os arquivos enviados
    destination: function (req, file, cb) {
        cb(null, uploadDir);
    },
    // Define o nome do arquivo salvo no servidor
    filename: function (req, file, cb) {

        //Date.now(): Retorna o número de milissegundos desde 1970 (um timestamp) - nome único. 
        cb(null, Date.now() + '-' + file.originalname);
    }
});

// Inicializa o Multer com a configuração de armazenamento
const upload = multer({ storage: storage });


//Arquivos estáticos (HTML, CSS, JS) da pasta 'public'
app.use(express.static('public'));

//--------------------------ROTA POST PARA UPLOAD DE ARQUIVOS--------------------------
// O 'upload.single('meuArquivo')' processa o arquivo.
// 'meuArquivo' deve ser o mesmo nome usado no FormData do lado do cliente.
app.post('/upload', upload.single('meuArquivo'), (req, res) => {
    if (!req.file) { //Arquivo enviado?
        return res.status(400).json({ message: 'Nenhum arquivo enviado.' });
    }
    res.status(200).json({ message: 'Upload realizado com sucesso!', file: req.file.filename });
});


//-----------ROTA GET PARA LISTAR OS ARQUIVOS - SOLICITA DADOS DO SERVIDOR--------------
app.get('/files', (req, res) => {
    // Lê o conteúdo do diretório de uploads
    fs.readdir(uploadDir, (err, files) => {
        if (err) {
            console.error("Erro ao ler o diretório de uploads:", err);
            return res.status(500).json({ message: 'Erro ao buscar arquivos.' });
        }
        // Retorna a lista de nomes de arquivos em formato JSON
        res.json(files);
    });
});



//-----ROTA GET PARA DOWNLOAD DE UM ARQUIVO ESPECÍFICO-----

/*
app.get('/download/:filename', ...): Rota GET dinâmica.

/:filename: O : filename é um parâmetro de rota. Ou seja, a rota irá corresponder a URLs como /download/arquivo1.txt

const filename = O Express extrai o valor do parâmetro da URL e o disponibiliza em req.params. 
Se a URL for /download/arquivo1.txt, req.params.filename será "arquivo1.txt".
*/

app.get('/download/:filename', (req, res) => {
    const filename = req.params.filename;
    const filePath = path.join(uploadDir, filename); // caminho completo para o arquivo solicitado no servidor

    // O método 'download' do Express envia o arquivo para o cliente,
    // forçando o navegador a abrir a caixa de diálogo de download.
    res.download(filePath, (err) => {
        if (err) {
            console.error("Erro no download:", err);
            // Se o arquivo não for encontrado ou outro erro ocorrer, envia uma resposta 404.
            res.status(404).send('Arquivo não encontrado.');
        }
    });
});

app.listen(port, () => {
    const url = `http://localhost:${port}`;
    console.log(`Servidor rodando em http://localhost:${port}`);
    console.log(`Diretório de uploads: ${uploadDir}`);

    (async () => {
        try {
            const openModule = await import('open');
            await openModule.default(url);
        } catch (error) {
            console.error('Erro ao tentar abrir o navegador:', error);
        }
    })();
});



