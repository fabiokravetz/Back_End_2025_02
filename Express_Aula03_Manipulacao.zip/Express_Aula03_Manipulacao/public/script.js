//'DOMContentLoaded': É o nome do evento. O navegador dispara este evento no exato momento em que ele terminou de carregar e construir toda a estrutura HTML da página.
document.addEventListener('DOMContentLoaded', () => {

    // Interação com os elementos do HTML.
    const uploadForm = document.getElementById('uploadForm');
    const fileInput = document.getElementById('fileInput');
    const fileList = document.getElementById('fileList');

    if (!uploadForm) {// Formulário não for encontrado?
        console.error('ERRO: Formulário com id="uploadForm" não foi encontrado.');
        return;
    }

    //Lista arquivos do servidor e exibe na página.
    async function loadFiles() {
        try {

            /*
            const response = await fetch('/files');: Esta é a chamada de rede.

            fetch('/files'): Envia uma requisição GET para a rota /files do nosso servidor Express.

            await: Pausa a execução da função loadFiles até que o servidor responda. A resposta é armazenada na variável response.

            const files = await response.json();: A resposta do servidor vem em um formato bruto. response.json() lê essa resposta e a converte em um objeto/array JavaScript (lembre-se que o servidor enviou res.json(files)).

            fileList.innerHTML = '';: Limpa completamente a lista de arquivos (<ul>) antes de adicionar os novos itens. Isso evita que a lista fique duplicada a cada atualização.
            */

            const response = await fetch('/files');
            const files = await response.json();
            
            fileList.innerHTML = ''; 
            
            if (files.length === 0) {
                fileList.innerHTML = '<li>Sem arquivos.</li>';
            } else {
                files.forEach(file => {
                    const li = document.createElement('li');
                    li.innerHTML = `<span>${file}</span> <a href="/download/${file}" download>Baixar</a>`;

                    //fileList.appendChild(li): Adiciona o novo item (<li>) à lista na página.
                    fileList.appendChild(li);
                });
            }
        } catch (error) {
            console.error('Erro ao carregar arquivos:', error);
            fileList.innerHTML = '<li>Erro ao carregar a lista de arquivos.</li>';
        }
    }



    /*
     Adiciona o "ouvinte" para o evento de 'submit' do formulário.

     async (event) => { ... }: A função que será executada quando o formulário for enviado.
    */
    uploadForm.addEventListener('submit', async (event) => {
        /*
        event.preventDefault();: Quando um formulário HTML é enviado, o navegador recarrega a página. Este comando cancela esse comportamento padrão, permitindo que nosso JavaScript controle e envie os dados 
        em segundo plano, sem recarregar a página.
        */
        event.preventDefault(); 
        
        if (!fileInput.files || fileInput.files.length === 0) {
            alert('Por favor, selecione um arquivo.');
            return;
        }

        //const formData = new FormData();: Cria um objeto FormData, que constrói um corpo de requisição que pode incluir arquivos, simulando um formulário HTML.

        const formData = new FormData();

        //formData.append('meuArquivo', fileInput.files[0]);: Adiciona o arquivo selecionado pelo usuário ao objeto formData.

        //fileInput.files[0]: Pega o primeiro arquivo que o usuário selecionou no campo <input type="file">.

        //const response = await fetch('/upload', { ... });: Envia a requisição de upload para o servidor.

        formData.append('meuArquivo', fileInput.files[0]);
        
        try {
            const response = await fetch('/upload', {
                method: 'POST',
                body: formData,
            });

            //const result = await response.json();: Pega a resposta JSON do servidor 
            // (ex: { message: 'Upload realizado...' }).

            const result = await response.json();

            if (response.ok) {//Verifica se a resposta HTTP teve um status de sucesso
                alert(result.message || 'Upload realizado com sucesso!');
                loadFiles(); // Atualiza a lista de arquivos.
            } else {
                throw new Error(result.message || 'Falha no upload.');
            }
        } catch (error) {
            console.error('Erro no upload:', error);
            alert('Erro no upload: ' + error.message);

            //uploadForm.reset() limpa o campo de seleção de arquivo, deixando-o pronto para um novo upload.

        } finally {
            uploadForm.reset(); 
        }
    });

    // Carrega a lista de arquivos.
    loadFiles();
    
    // Anexa a função loadFiles ao objeto window para que o botão 'onclick' possa encontrá-la.
    window.loadFiles = loadFiles;
});