const express = require('express');
const path = require('path');
const produtoRoutes = require('./routes/produtoRoutes'); // Importação das rotas

const app = express();
const port = 3000;

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(express.static(path.join(__dirname, 'public')));

app.use(express.urlencoded({ extended: true }));

//Entrega a requisição para o roteador de produtos.
app.use('/produtos', produtoRoutes);

app.get('/', (req, res) => {
    res.redirect('/produtos');
});

app.listen(port, () => {
    const url = `http://localhost:${port}`;
    console.log(`Servidor da loja rodando em ${url}`);

    (async () => {
        try {
            const openModule = await import('open');
            await openModule.default(url);
        } catch (error) {
            console.error('Erro ao tentar abrir o navegador:', error);
        }
    })();
});

